from django.urls import path
from  . import views

urlpatterns = [
    path('home.html',views.homepageview,name="home"),
    path('about.html',views.aboutpageview,name="about"),
    path('contact.html',views.contactpageview,name="contact"),
    path('registration.html',views.registrationpageview,name="registration"),
    path('formprocess',views.process,name="process"),
    
]