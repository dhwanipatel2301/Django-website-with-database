from typing import Text
from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponse

def homepageview(request):
    return render(request,'home.html')
    
def aboutpageview(request):
    return render(request,'about.html')    

def contactpageview(request):
    return render(request,'contact.html')

def registrationpageview(request):
    return render(request,'registration.html')

def process(request):
    print("Welcome To GreenWorld !!")
    print(request.method)
    print(request.POST)
     
    a = Text(request.POST['firstname'])
    b = Text(request.POST['lastname'])
    c = Text(request.POST['contact'])
    e = Text(request.POST['country'])
    f = Text(request.POST['city'])
    g = Text(request.POST['email'])
    h = Text(request.POST['psw'])
    i = a + b + c  + e + f + g + h
    print(i)
    return render(request,'print.html',{'myfirstname':a, 'mylastname':b, 'mycontact':c, 'mycountry':e, 'mycity':f, 'myemail':g, 'mypsw':h}) 

