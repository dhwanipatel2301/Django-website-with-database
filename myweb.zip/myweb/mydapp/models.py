from django.db import models
from django.db.models.query_utils import check_rel_lookup_compatibility

# Create your models here.

class student(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    gender = models.BooleanField(default=False)
    country = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=30)
    

    