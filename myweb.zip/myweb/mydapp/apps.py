from django.apps import AppConfig


class MydappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mydapp'
